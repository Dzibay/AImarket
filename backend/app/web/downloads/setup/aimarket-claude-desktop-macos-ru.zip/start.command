#!/usr/bin/env bash
set -u
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SH_SCRIPT="$SCRIPT_DIR/setup-aimarket-claude-desktop.sh"
if [[ ! -f "$SH_SCRIPT" ]]; then
  printf '[FAIL] setup-aimarket-claude-desktop.sh was not found next to this file.\n' >&2
  printf '\nPress Enter to close this window.'
  read -r _ || true
  exit 1
fi
bash "$SH_SCRIPT" --lang ru "$@"
SETUP_EXIT_CODE=$?
printf '\nPress Enter to close this window.'
read -r _ || true
exit "$SETUP_EXIT_CODE"