#!/usr/bin/env bash
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SH_SCRIPT="$SCRIPT_DIR/setup-aimarket.sh"

if [[ ! -f "$SH_SCRIPT" ]]; then
  printf '[FAIL] setup-aimarket.sh was not found. Extract the whole archive, then run start.command again.\n' >&2
  printf '\nPress Enter to close this window.'
  read -r _ || true
  exit 1
fi

bash "$SH_SCRIPT" --app grok-build "$@"
SETUP_EXIT_CODE=$?

printf '\nPress Enter to close this window.'
read -r _ || true
exit "$SETUP_EXIT_CODE"
