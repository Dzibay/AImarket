@echo off
setlocal
chcp 1251 >nul 2>nul
title aimarket setup
set "SCRIPT_DIR=%~dp0"
set "PS1_SCRIPT=%SCRIPT_DIR%setup-aimarket.ps1"
if not exist "%PS1_SCRIPT%" (
  echo [FAIL] setup-aimarket.ps1 not found next to this file.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1_SCRIPT%" -Lang ru -App claude-code %*
set "SETUP_EXIT_CODE=%ERRORLEVEL%"
echo.
echo Press any key to close this window.
pause >nul
exit /b %SETUP_EXIT_CODE%