#!/usr/bin/env bash
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SH_SCRIPT="$SCRIPT_DIR/setup-routercheap.sh"

printf '\nrouter.cheap app setup\n'
printf '======================\n\n'

if [[ ! -f "$SH_SCRIPT" ]]; then
  printf '[FAIL] setup-routercheap.sh was not found next to this .command file.\n' >&2
  printf 'Put both files in the same folder and run this file again.\n' >&2
  printf '\nPress Enter to close this window.'
  read -r _ || true
  exit 1
fi

bash "$SH_SCRIPT" "$@"
SETUP_EXIT_CODE=$?

printf '\n'
if [[ "$SETUP_EXIT_CODE" -eq 0 ]]; then
  printf '[OK] Finished.\n'
else
  printf '[FAIL] Setup failed with exit code %s.\n' "$SETUP_EXIT_CODE"
fi

printf '\nPress Enter to close this window.'
read -r _ || true
exit "$SETUP_EXIT_CODE"
