@echo off
setlocal
chcp 1251 >nul 2>nul
title router.cheap setup
set "SCRIPT_DIR=%~dp0"
set "PS1_SCRIPT=%SCRIPT_DIR%setup-routercheap.ps1"
if not exist "%PS1_SCRIPT%" (
  echo [FAIL] setup-routercheap.ps1 not found next to this file.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1_SCRIPT%" -Lang ru -App grok-build %*
set "SETUP_EXIT_CODE=%ERRORLEVEL%"
echo.
echo Press any key to close this window.
pause >nul
exit /b %SETUP_EXIT_CODE%